set (ODA_EXE_MANIFEST 2)

if(MSVC AND MSVC_VERSION LESS 1929)
  add_compile_options(/wd4138) #https://developercommunity.visualstudio.com/t/warning-c4138-found-outside-of-comment/1182287
endif(MSVC AND MSVC_VERSION LESS 1929)

###################################
# MSVC Multiprocessor build support
###################################
if(MSVC AND NOT WINCE)
  if(MSVC_MP)
    add_compile_options("/MP${MSVC_MP}")
  else(MSVC_MP)
    add_compile_options("/MP")  
  endif(MSVC_MP)
  set(MSVC_MP_KEY "/MP${MSVC_MP}")
  message("MSVC CL threads option is ${MSVC_MP_KEY}")  
endif(MSVC AND NOT WINCE)

###########################
# Add ODA flag modifiers to initial flags
###########################
MACRO(join_strings OUTVAR)
set(TMPVAR "")
foreach(INVAR ${ARGN})
  if(${INVAR})
    if(${OUTVAR})
      set(TMPVAR "${TMPVAR} ")
    endif(${OUTVAR})
    set(TMPVAR "${TMPVAR}${${INVAR}}")
  endif(${INVAR})
endforeach()
set(${OUTVAR} ${TMPVAR})
ENDMACRO(join_strings OUTVAR)

join_strings(CMAKE_EXE_LINKER_FLAGS CMAKE_EXE_LINKER_FLAGS ODA_EXE_LINKER_FLAGS)
join_strings(CMAKE_EXE_LINKER_FLAGS_${CMAKE_BUILD_TYPE} CMAKE_EXE_LINKER_FLAGS_${CMAKE_BUILD_TYPE} ODA_EXE_LINKER_FLAGS_${CMAKE_BUILD_TYPE})
join_strings(CMAKE_SHARED_LINKER_FLAGS CMAKE_SHARED_LINKER_FLAGS ODA_SHARED_LINKER_FLAGS)
join_strings(CMAKE_SHARED_LINKER_FLAGS_${CMAKE_BUILD_TYPE} CMAKE_SHARED_LINKER_FLAGS_${CMAKE_BUILD_TYPE} ODA_SHARED_LINKER_FLAGS_${CMAKE_BUILD_TYPE})
join_strings(CMAKE_CXX_FLAGS_${CMAKE_BUILD_TYPE} CMAKE_CXX_FLAGS_${CMAKE_BUILD_TYPE} ODA_CXX_FLAGS_${CMAKE_BUILD_TYPE})
join_strings(CMAKE_C_FLAGS_${CMAKE_BUILD_TYPE} CMAKE_C_FLAGS_${CMAKE_BUILD_TYPE} ODA_C_FLAGS_${CMAKE_BUILD_TYPE})
join_strings(CMAKE_CXX_FLAGS CMAKE_CXX_FLAGS ODA_CXX_FLAGS ODA_CMD_CXX_FLAGS)
join_strings(CMAKE_C_FLAGS CMAKE_C_FLAGS ODA_C_FLAGS ODA_CMD_C_FLAGS)

MACRO(oda_message)
  if(ODA_MESSAGE_ENABLED)
    message(${ARGN})
  endif()
ENDMACRO(oda_message)

###########################
# Activation support
###########################
MACRO(add_activation_include_dirs)
include_directories(
  ${CMAKE_SOURCE_DIR}/ThirdParty
  ${CMAKE_SOURCE_DIR}/ThirdParty/activation
)
ENDMACRO(add_activation_include_dirs)

###########################
# Mobile Platforms definition
###########################
IF(IOS OR ANDROID OR WINRT OR WINCE)
  set(ODA_MOBILE_PLATFORMS 1)
  #IF(ANDROID OR WINRT OR WINCE)
    set(ODA_HAVENOT_EXECUTABLE 1)
  #ENDIF(ANDROID OR WINRT OR WINCE)
ENDIF(IOS OR ANDROID OR WINRT OR WINCE)

# Apple Silicon
if(MAC_ARM)
add_definitions(-DMACOS_ARM)
endif()

###########################
# Trial builds support
###########################
IF(DEFINED TEIGHA_TRIAL)
  MESSAGE("Trial builds are ENABLED")
  add_definitions(-DTEIGHA_TRIAL)
ENDIF(DEFINED TEIGHA_TRIAL)

############################
# Setup QT version variables
############################
if(EXISTS $ENV{QTDIR})
find_program(QMAKE_EXECUTABLE NAMES qmake HINTS ${QTDIR} ENV QTDIR PATH_SUFFIXES bin)
execute_process(COMMAND ${QMAKE_EXECUTABLE} -query QT_VERSION OUTPUT_VARIABLE QT_VERSION)
message ("QT Version is ${QT_VERSION}")

if(NOT EXISTS $ENV{CMAKE_PREFIX_PATH})
  set(CMAKE_PREFIX_PATH "${CMAKE_PREFIX_PATH};$ENV{QTDIR}")
endif(NOT EXISTS $ENV{CMAKE_PREFIX_PATH})

if(${QT_VERSION} VERSION_GREATER 6.0.0)
  set(QT6 1)
  find_package(QtitanRibbon6)
  set(QTITANRIBBON_FOUND ${QTITANRIBBON6_FOUND})
  set(ODA_QT_PREFIX Qt6)
elseif(${QT_VERSION} VERSION_GREATER 5.0.0)
  set(QT5 1)
  find_package(QtitanRibbon)
  set(ODA_QT_PREFIX Qt5)
endif()
endif(EXISTS $ENV{QTDIR})

set(ENV{_ODA_STORE_PRODUCTS_TARGETS} "")

###########################
# oda_get_product_name
###########################
MACRO(oda_get_product_name)
  file(RELATIVE_PATH _ODA_PRODUCT_NAME ${CMAKE_SOURCE_DIR} ${CMAKE_CURRENT_SOURCE_DIR})
  file(TO_CMAKE_PATH "${_ODA_PRODUCT_NAME}" _ODA_PRODUCT_NAME)
  string(REGEX REPLACE "\/.*" "" _ODA_PRODUCT_NAME "${_ODA_PRODUCT_NAME}")

  set(_ODA_STORE_PRODUCTS_TARGETS $ENV{_ODA_STORE_PRODUCTS_TARGETS})
  list(FIND _ODA_STORE_PRODUCTS_TARGETS ${_ODA_PRODUCT_NAME} _ODA_PRODUCT_FOUND)
  if(_ODA_PRODUCT_FOUND EQUAL -1)
      list(APPEND _ODA_STORE_PRODUCTS_TARGETS ${_ODA_PRODUCT_NAME})
      set(ENV{_ODA_STORE_PRODUCTS_TARGETS} "${_ODA_STORE_PRODUCTS_TARGETS}")
      file(WRITE "${CMAKE_BINARY_DIR}/${_ODA_PRODUCT_NAME}.targets" "")
  endif()
  unset(_ODA_STORE_PRODUCTS_TARGETS)
  unset(_ODA_PRODUCT_FOUND)
ENDMACRO(oda_get_product_name)

###########################
# oda_target_outputname
###########################
MACRO(oda_target_outputname TARGET_NAME)
  if(TARGET ${TARGET_NAME})
    message(SEND_ERROR "Set OUTPUT_NAME before adding target")
  endif()
  if(${ARGV1} MATCHES "^(ARCHIVE|LIBRARY|RUNTIME)$")
    set(${TARGET_NAME}_${ARGV1}_OUTPUT_NAME "${ARGV2}")
  else()
    set(${TARGET_NAME}_OUTPUT_NAME "${ARGV1}")
  endif()
ENDMACRO(oda_target_outputname)

###########################
# oda_add_library
###########################
MACRO(oda_add_library TARGET_NAME)
  oda_get_product_name()

  if(${TARGET_NAME}_OUTPUT_NAME)
    set(_ODA_LIB_NAMES ${${TARGET_NAME}_OUTPUT_NAME})
  else()
    set(_ODA_LIB_NAMES ${TARGET_NAME})
  endif()
  foreach(_ODA_OUTPUTNAME_TYPE ARCHIVE LIBRARY RUNTIME)
    if(${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME)
      list(INSERT _ODA_LIB_NAMES 0 ${${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME})
    endif()
  endforeach()

  if("$ENV{ODA_CACHE}" AND EXISTS "${CMAKE_BINARY_DIR}/${_ODA_PRODUCT_NAME}.binaries" AND NOT ODA_CACHE_DISABLE)
    find_library(_ODA_LIB_ADD_PATH NAMES ${_ODA_LIB_NAMES} PATHS ${ODA_BIN_DIR} ${ODA_LIB_DIR} NO_DEFAULT_PATH)
  else()
    set(_ODA_LIB_ADD_PATH "_ODA_LIB_ADD_PATH-NOTFOUND")
  endif()

  if(${_ODA_LIB_ADD_PATH} STREQUAL "_ODA_LIB_ADD_PATH-NOTFOUND")
    add_library(${TARGET_NAME} ${ARGN})
    if(${TARGET_NAME}_OUTPUT_NAME)
      set_target_properties(${TARGET_NAME} PROPERTIES OUTPUT_NAME ${${TARGET_NAME}_OUTPUT_NAME})
    endif()
    foreach(_ODA_OUTPUTNAME_TYPE ARCHIVE LIBRARY RUNTIME)
      if(${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME)
        set_target_properties(${TARGET_NAME} PROPERTIES OUTPUT_NAME ${${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME})
      endif()
    endforeach()
    set(_ODA_TARGET_GEN "build")
  else()
    if(${ARGV1} MATCHES "^(SHARED|STATIC|MODULE)$")
      set(TARGET_TYPE ${ARGV1})
    else()
      set(TARGET_TYPE STATIC)
    endif()
    add_library(${TARGET_NAME} ${TARGET_TYPE} IMPORTED GLOBAL)
    set_target_properties(${TARGET_NAME} PROPERTIES
      IMPORTED_IMPLIB ${_ODA_LIB_ADD_PATH}
      IMPORTED_LOCATION ${_ODA_LIB_ADD_PATH}
    )
    set(_ODA_TARGET_GEN "cache")
  endif()
  string(TIMESTAMP _ODA_TIMESTAMP "%Y-%m-%d %H:%M:%S")
  message("${_ODA_TIMESTAMP} ${_ODA_PRODUCT_NAME} ${TARGET_NAME} ${_ODA_TARGET_GEN}")
  file(APPEND "${CMAKE_BINARY_DIR}/${_ODA_PRODUCT_NAME}.targets" "${TARGET_NAME};${_ODA_TARGET_GEN};${_ODA_LIB_NAMES}\n")

  unset(_ODA_PRODUCT_NAME CACHE)
  unset(_ODA_LIB_ADD_PATH CACHE)
ENDMACRO(oda_add_library)

########################
# oda_add_executable
########################
MACRO(oda_add_executable TARGET_NAME)
  oda_get_product_name()

  if(${TARGET_NAME}_OUTPUT_NAME)
    set(_ODA_BIN_NAMES ${${TARGET_NAME}_OUTPUT_NAME})
  else()
    set(_ODA_BIN_NAMES ${TARGET_NAME})
  endif()
  foreach(_ODA_OUTPUTNAME_TYPE ARCHIVE LIBRARY RUNTIME)
    if(${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME)
      list(INSERT _ODA_BIN_NAMES 0 ${${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME})
    endif()
  endforeach()

  if("$ENV{ODA_CACHE}" AND EXISTS "${CMAKE_BINARY_DIR}/${_ODA_PRODUCT_NAME}.binaries")
    find_program(_ODA_BIN_ADD_PATH NAMES ${_ODA_BIN_NAMES} PATHS ${ODA_BIN_DIR} NO_DEFAULT_PATH)
  else()
    set(_ODA_BIN_ADD_PATH "_ODA_BIN_ADD_PATH-NOTFOUND")
  endif()

  if(${_ODA_BIN_ADD_PATH} STREQUAL "_ODA_BIN_ADD_PATH-NOTFOUND")
    add_executable(${TARGET_NAME} ${ARGN})
    if(${TARGET_NAME}_OUTPUT_NAME)
      set_target_properties(${TARGET_NAME} PROPERTIES OUTPUT_NAME ${${TARGET_NAME}_OUTPUT_NAME})
    endif()
    foreach(_ODA_OUTPUTNAME_TYPE ARCHIVE LIBRARY RUNTIME)
      if(${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME)
        set_target_properties(${TARGET_NAME} PROPERTIES OUTPUT_NAME ${${TARGET_NAME}_${_ODA_OUTPUTNAME_TYPE}_OUTPUT_NAME})
      endif()
    endforeach()
    set(_ODA_TARGET_GEN "build")
  else()
    add_executable(${TARGET_NAME} IMPORTED GLOBAL)
    set_target_properties(${TARGET_NAME} PROPERTIES IMPORTED_LOCATION ${_ODA_BIN_ADD_PATH})
    set(_ODA_TARGET_GEN "cache")
  endif()
  string(TIMESTAMP _ODA_TIMESTAMP "%Y-%m-%d %H:%M:%S")
  message("${_ODA_TIMESTAMP} ${_ODA_PRODUCT_NAME} ${TARGET_NAME} ${_ODA_TARGET_GEN}")
  file(APPEND "${CMAKE_BINARY_DIR}/${_ODA_PRODUCT_NAME}.targets" "${TARGET_NAME};${_ODA_TARGET_GEN};${_ODA_BIN_NAMES}\n")

  unset(_ODA_PRODUCT_NAME CACHE)
  unset(_ODA_BIN_ADD_PATH CACHE)
ENDMACRO(oda_add_executable)

###########################
# oda_sources TARGET_NAME
###########################
MACRO(oda_sources TARGET_NAME)
  set (${TARGET_NAME}_SRCS ${${TARGET_NAME}_SRCS} ${ARGN})
  set(LIBRARY_OUTPUT_PATH ${ODA_LIB_DIR})
ENDMACRO(oda_sources)

###########################
# oda_link_libraries_internal
###########################
MACRO(oda_link_libraries_internal TARGET_NAME)
  if(BORLAND OR MSVC OR WINDOWS_GCC)
    foreach(lib ${ARGN})
      if(NOT ${lib} IN_LIST ${TARGET_NAME}_LIBS)
        set(${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${lib} CACHE INTERNAL "internal")
      endif()
    endforeach(lib)
    unset(_lib_dep)
    foreach(dep ${ARGN})
      foreach(lib ${${dep}_LIBS} ${${dep}_LIBRARIES})
        if(NOT ${lib} IN_LIST ${TARGET_NAME}_LIBS)
          list(APPEND _lib_dep ${lib})
        endif()
      endforeach()
    endforeach()
    list(REMOVE_DUPLICATES _lib_dep)
    if(NOT "${_lib_dep}" STREQUAL "")
      oda_link_libraries_internal(${TARGET_NAME} ${_lib_dep})
    endif()
  else(BORLAND OR MSVC OR WINDOWS_GCC)
    foreach(lib ${ARGN})
      if(TARGET ${lib})
        if(NOT EMCC AND NOT ANDROID)
          set(_target_LOC "$<TARGET_FILE_DIR:${lib}>")
        else(NOT EMCC AND NOT ANDROID)
          set(_target_LOC "_target_LOC-NOTFOUND")
        endif(NOT EMCC AND NOT ANDROID)
      else()
        set(_target_LOC _target_LOC-NOTFOUND)
      endif()
      if(_target_LOC)
        set(${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${lib} CACHE INTERNAL "internal")
      else(_target_LOC)
        set(_LIB "_LIB-NOTFOUND")
        if (ODA_RELEASE)
          find_library(_LIB NAMES ${lib} PATHS  ${ODA_LIB_DIR} NO_DEFAULT_PATH )
        else (ODA_RELEASE)
          find_library(_LIB NAMES ${lib} PATHS ${ODA_BIN_DIR} ${ODA_LIB_DIR} NO_DEFAULT_PATH )
        endif (ODA_RELEASE)
        if(${_LIB} STREQUAL "_LIB-NOTFOUND")
          if(EXISTS ${ODA_BIN_DIR}/${lib}.tx)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.tx CACHE INTERNAL "internal" )
          elseif(EXISTS ${ODA_BIN_DIR}/${lib}.txv)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.txv CACHE INTERNAL "internal" )
          elseif(EXISTS ${ODA_BIN_DIR}/${lib}.txr)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.txr CACHE INTERNAL "internal" )
          elseif(EXISTS ${ODA_BIN_DIR}/${lib}.txexp)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.txexp CACHE INTERNAL "internal" )
          else()
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${lib} CACHE INTERNAL "internal" )
          endif()
        else(${_LIB} STREQUAL "_LIB-NOTFOUND")
          set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${_LIB} CACHE INTERNAL "internal" )
        endif(${_LIB} STREQUAL "_LIB-NOTFOUND")
      endif(_target_LOC)
      foreach (dep ${${lib}_LIBRARIES})
        oda_link_libraries_internal(${TARGET_NAME} ${dep})
      endforeach()
  endforeach(lib)
  endif(BORLAND OR MSVC OR WINDOWS_GCC)
ENDMACRO(oda_link_libraries_internal)

###########################
# oda_link_libraries_internal_dll
###########################
MACRO(oda_link_libraries_internal_dll TARGET_NAME)
  if(BORLAND OR MSVC OR WINDOWS_GCC)
      foreach(lib ${ARGN})
        #if (NOT ${lib}_EXTENSION EQUAL 1)
        if(NOT ${lib} IN_LIST ${TARGET_NAME}_LIBS)
          set(${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${lib} CACHE INTERNAL "internal")
        endif()
        #endif()
      endforeach(lib)
    foreach (dep ${ARGN})
      if(NOT "${${dep}_LIBS}" STREQUAL "")
        oda_link_libraries_internal(${TARGET_NAME} ${${dep}_LIBS})
      endif()
      foreach (lib ${${dep}_LIBRARIES})
        oda_link_libraries_internal_dll(${TARGET_NAME} ${lib})
      endforeach()
    endforeach()
  else(BORLAND OR MSVC OR WINDOWS_GCC)
    foreach(lib ${ARGN})
      if(TARGET ${lib})
        if(NOT EMCC AND NOT ANDROID)
          set(_target_LOC "$<TARGET_FILE_DIR:${lib}>")
        else(NOT EMCC AND NOT ANDROID)
          set(_target_LOC "_target_LOC-NOTFOUND")
        endif(NOT EMCC AND NOT ANDROID)
      else()
        set(_target_LOC _target_LOC-NOTFOUND)
      endif()
      if(_target_LOC)
        set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${lib} CACHE INTERNAL "internal" )
      else(_target_LOC)
        set(_LIB "_LIB-NOTFOUND")
        if (ODA_RELEASE)
          find_library(_LIB NAMES ${lib} PATHS  ${ODA_LIB_DIR} NO_DEFAULT_PATH )
        else (ODA_RELEASE)
          find_library(_LIB NAMES ${lib} PATHS ${ODA_BIN_DIR} ${ODA_LIB_DIR} NO_DEFAULT_PATH )
        endif (ODA_RELEASE)
        if(${_LIB} STREQUAL "_LIB-NOTFOUND")
          if(EXISTS ${ODA_BIN_DIR}/${lib}.tx)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.tx CACHE INTERNAL "internal" )
          elseif(EXISTS ${ODA_BIN_DIR}/${lib}.txv)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.txv CACHE INTERNAL "internal" )
          elseif(EXISTS ${ODA_BIN_DIR}/${lib}.txr)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.txr CACHE INTERNAL "internal" )
          elseif(EXISTS ${ODA_BIN_DIR}/${lib}.txexp)
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${ODA_BIN_DIR}/${lib}.txexp  CACHE INTERNAL "internal" )
          else()
            set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${lib} CACHE INTERNAL "internal" )
          endif()
        else(${_LIB} STREQUAL "_LIB-NOTFOUND")
          set( ${TARGET_NAME}_LIBS ${${TARGET_NAME}_LIBS} ${_LIB} CACHE INTERNAL "internal" )
        endif(${_LIB} STREQUAL "_LIB-NOTFOUND")
      endif(_target_LOC)
      foreach (dep ${${lib}_LIBRARIES})
        oda_link_libraries_internal_dll(${TARGET_NAME} ${dep})
      endforeach()
  endforeach(lib)
  endif(BORLAND OR MSVC OR WINDOWS_GCC)
ENDMACRO(oda_link_libraries_internal_dll)

###########################
# oda_target_link_libraries
###########################
MACRO(oda_target_link_libraries TARGET_NAME)
  get_target_property(_target_IMPORTED ${TARGET_NAME} IMPORTED)
  if(NOT _target_IMPORTED)
    if(NOT "${ARGN}" STREQUAL "")
      if(NOT "${ARGV1}" MATCHES "^(PRIVATE|PUBLIC|INTERFACE)$")
        set(_target_LINK_TYPE PUBLIC)
      endif()
      target_link_libraries(${TARGET_NAME} ${_target_LINK_TYPE} ${ARGN})
      unset(_target_LINK_TYPE)
    endif()
  endif()
  unset(_target_IMPORTED CACHE)
ENDMACRO(oda_target_link_libraries)

###########################
# oda_link_libraries
###########################
MACRO(oda_link_libraries TARGET_NAME)
  unset(${TARGET_NAME}_LIBS CACHE)
  oda_link_libraries_internal (${TARGET_NAME} ${ARGN})
  oda_target_link_libraries(${TARGET_NAME} ${${TARGET_NAME}_LIBS} ${ODA_PLATFORM_LIBS})
ENDMACRO(oda_link_libraries)

###########################
# oda_link_libraries_dll
###########################
MACRO(oda_link_libraries_dll TARGET_NAME)
  unset(${TARGET_NAME}_LIBS CACHE)
  oda_link_libraries_internal_dll (${TARGET_NAME} ${ARGN})
  oda_target_link_libraries(${TARGET_NAME} ${${TARGET_NAME}_LIBS} ${ODA_PLATFORM_LIBS})
ENDMACRO(oda_link_libraries_dll)

###########################
# oda_target_compile_defs
###########################
MACRO(oda_target_compile_defs TARGET_NAME)
  get_target_property(_target_IMPORTED ${TARGET_NAME} IMPORTED)
  if(NOT _target_IMPORTED)
    target_compile_definitions(${TARGET_NAME} ${ARGN})
  endif()
  unset(_target_IMPORTED CACHE)
ENDMACRO(oda_target_compile_defs)

###########################
# oda_target_compile_opts
###########################
MACRO(oda_target_compile_opts TARGET_NAME)
  get_target_property(_target_IMPORTED ${TARGET_NAME} IMPORTED)
  if(NOT _target_IMPORTED)
    target_compile_options(${TARGET_NAME} ${ARGN})
  endif()
  unset(_target_IMPORTED CACHE)
ENDMACRO(oda_target_compile_opts)

###########################
# oda_target_include_dirs
###########################
MACRO(oda_target_include_dirs TARGET_NAME)
  get_target_property(_target_IMPORTED ${TARGET_NAME} IMPORTED)
  if(NOT _target_IMPORTED)
    target_include_directories(${TARGET_NAME} ${ARGN})
  endif()
  unset(_target_IMPORTED CACHE)
ENDMACRO(oda_target_include_dirs)

###########################
# oda_define_target_desc
###########################
MACRO (oda_define_target_desc TARGET_NAME)
  foreach(arg ${ARGN})
    if (${arg} STREQUAL "INCLUDE_DIRECTORIES")
      set(arg_append_var ${TARGET_NAME}_INCLUDE_DIR)
    elseif(${arg} STREQUAL "LINK_DIRECTORIES")
      set(arg_append_var ${TARGET_NAME}_LIBRARY_DIR)
    elseif(${arg} STREQUAL "LIBRARIES")
      set(arg_append_var ${TARGET_NAME}_LIBRARIES)
    elseif(${arg} STREQUAL "DEFINITIONS")
      set(arg_append_var ${TARGET_NAME}_DEFINITIONS)
    elseif(${arg} STREQUAL "EXTENSION")
      set(${TARGET_NAME}_EXTENSION 1)
    else()
      set (${arg_append_var} ${${arg_append_var}} ${arg})
    endif()
  endforeach(arg)
ENDMACRO(oda_define_target_desc)

###########################
# oda_import_component_deps
###########################
MACRO (oda_import_component_deps TARGET_NAME)
  foreach(lib ${ARGN})
    foreach (dir ${${lib}_INCLUDE_DIR})
      include_directories(${dir})
    endforeach(dir ${${lib}_INCLUDE_DIR})
    foreach (dir ${${lib}_LIBRARY_DIR})
      link_directories(${dir})
    endforeach(dir ${${lib}_LIBRARY_DIR})
    foreach (def ${${lib}_DEFINITIONS})
      add_definitions(${def})
    endforeach(def ${${lib}_DEFINITIONS})
    foreach (dep ${${lib}_LIBRARIES})
      oda_import_component_deps(${dep})
    endforeach(dep ${${lib}_LIBRARIES})
  endforeach(lib)
ENDMACRO(oda_import_component_deps)

MACRO(oda_init_rpath)
  set(CMAKE_SKIP_BULD_RPATH false)
  set(CMAKE_BUILD_WITH_INSTALL_RPATH false)
  if(LINUX_X86 OR LINUX_X64 OR LINUX_ARM)
    set(CMAKE_INSTALL_RPATH $ORIGIN)
  elseif(MACOS_X86 OR MACOS_X64 OR MACOS_ARM)
    set(CMAKE_INSTALL_NAME_DIR @executable_path)
    set(CMAKE_INSTALL_RPATH @executable_path)
  endif()
ENDMACRO(oda_init_rpath)

###########################
# oda_tx TARGET_NAME
###########################
MACRO(oda_tx TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
 if(STATIC_OPENSSL)
 add_definitions(-DSTATIC_OPENSSL)
 endif(STATIC_OPENSSL)
if(ODA_SHARED)
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES SUFFIX ".tx")
  oda_link_libraries (${TARGET_NAME} ${ARGN})
    if(MSVC OR BORLAND OR WINDOWS_GCC)
      set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
      set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
    else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE ${ODA_LIB_DIR}/${TARGET_NAME}.tx)")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
    endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
else(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_tx)

###########################
# oda_txv TARGET_NAME
###########################
MACRO(oda_txv TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
if(ODA_SHARED)
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES SUFFIX ".txv")
  oda_link_libraries (${TARGET_NAME} ${ARGN})
    if(MSVC OR BORLAND OR WINDOWS_GCC)
      set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
      set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
    else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE  ${ODA_LIB_DIR}/${TARGET_NAME}.txv)")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
    endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
else(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_txv)

###########################
# oda_txr TARGET_NAME
###########################
MACRO(oda_txr TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
if(ODA_SHARED)
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES SUFFIX ".txr")
  oda_link_libraries (${TARGET_NAME} ${ARGN})
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE  ${ODA_LIB_DIR}/${TARGET_NAME}.txr)")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
    endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
else(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_txr)

###########################
# oda_txexp TARGET_NAME
###########################
MACRO(oda_txexp TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
if(ODA_SHARED)
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES SUFFIX ".txexp")
  oda_link_libraries (${TARGET_NAME} ${ARGN})
    if(MSVC OR BORLAND OR WINDOWS_GCC)
      set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
      set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
    else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE ${ODA_LIB_DIR}/${TARGET_NAME}.txexp)")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
    endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
else(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_txexp)

###########################
# oda_component TARGET_NAME
###########################
MACRO(oda_component TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
if(ODA_SHARED)
  oda_check_td_alloc(${TARGET_NAME} ${ARGN})
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  oda_link_libraries (${TARGET_NAME} ${ARGN} ${ODA_PLATFORM_LIBS} )
  if(${${TARGET_NAME}_VER})
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  endif(${${TARGET_NAME}_VER})
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE  ${ODA_LIB_DIR}/${CMAKE_SHARED_LIBRARY_PREFIX}${TARGET_NAME}${CMAKE_SHARED_LIBRARY_SUFFIX})")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  oda_set_no_precompiled_header_for_file("${TKERNELBASE_ROOT}/Extensions/alloc/OdAllocOp.cpp")
else(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY  ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_component)


###########################
# oda_component_dll TARGET_NAME
###########################
MACRO(oda_component_dll TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  oda_check_td_alloc(${TARGET_NAME} ${ARGN})
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  oda_link_libraries_dll (${TARGET_NAME} ${ARGN} ${ODA_PLATFORM_LIBS} )
  if(${${TARGET_NAME}_VER})
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  endif(${${TARGET_NAME}_VER})
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE  ${ODA_LIB_DIR}/${CMAKE_SHARED_LIBRARY_PREFIX}${TARGET_NAME}${CMAKE_SHARED_LIBRARY_SUFFIX})")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  oda_set_no_precompiled_header_for_file("${TKERNELBASE_ROOT}/Extensions/alloc/OdAllocOp.cpp")
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_component_dll)

###########################
# oda_tx_component TARGET_NAME - kind of component with ODRX_DEFINE_DYNAMIC_MODULE macros
###########################
MACRO(oda_tx_component TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
if(ODA_SHARED)
  add_definitions(-D_TOOLKIT_IN_DLL_)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  oda_link_libraries (${TARGET_NAME} ${ARGN} ${ODA_PLATFORM_LIBS} )
  if(${${TARGET_NAME}_VER})
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  endif(${${TARGET_NAME}_VER})
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE  ${ODA_LIB_DIR}/${CMAKE_SHARED_LIBRARY_PREFIX}${TARGET_NAME}${CMAKE_SHARED_LIBRARY_SUFFIX})")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(MSVC OR BORLAND OR WINDOWS_GCC)
          set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
else(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_tx_component)

###########################
# oda_module TARGET_NAME
###########################
MACRO(oda_module TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_init_rpath()  
  if(ODA_SHARED)
    add_definitions(-D_TOOLKIT_IN_DLL_)
  endif(ODA_SHARED)
  oda_add_library (${TARGET_NAME} SHARED ${${TARGET_NAME}_SRCS})
  oda_link_libraries (${TARGET_NAME} ${ARGN} ${ODA_PLATFORM_LIBS} )
  if(${${TARGET_NAME}_VER})
  if(ODA_VER)
    set_target_properties( ${TARGET_NAME} PROPERTIES VERSION ${ODA_VER})
  endif(ODA_VER)
  endif(${${TARGET_NAME}_VER})
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  else(MSVC OR BORLAND OR WINDOWS_GCC)
  if(ODA_RELEASE)
    install(TARGETS ${TARGET_NAME}  LIBRARY DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    install(CODE "file(REMOVE  ${ODA_LIB_DIR}/${CMAKE_SHARED_LIBRARY_PREFIX}${TARGET_NAME}${CMAKE_SHARED_LIBRARY_SUFFIX})")
  else(ODA_RELEASE)
    set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  endif(ODA_RELEASE)
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties(${TARGET_NAME} PROPERTIES PREFIX "")
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(MSVC AND NOT ODA_SHARED)
    set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY  ${ODA_LIB_DIR})
    set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
  endif(MSVC AND NOT ODA_SHARED)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_module)

###########################
# oda_library TARGET_NAME
###########################
MACRO(oda_library TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
  if(ODA_SHARED)
    add_definitions(-D_TOOLKIT_IN_DLL_)
  endif(ODA_SHARED)
  oda_add_library (${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  set_target_properties(${TARGET_NAME} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES ARCHIVE_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
if(MSVC)
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_OUTPUT_DIRECTORY ${ODA_LIB_DIR})
  set_target_properties(${TARGET_NAME} PROPERTIES COMPILE_PDB_NAME ${TARGET_NAME})
endif(MSVC)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_FLAG}")
  endif(IOS)
ENDMACRO(oda_library)

########################
# oda_executable(TARGET_NAME)
########################
MACRO(oda_executable TARGET_NAME)
  add_definitions(${TD_CORE_DEFS})
  include_directories(${TKERNELBASE_ROOT})
  include_directories(${TKERNELBASE_ROOT}/Source)
  include_directories(BEFORE ${TKERNELBASE_CORE_INCLUDE})
  add_activation_include_dirs()
  oda_import_component_deps(${TARGET_NAME} ${ARGN})
  oda_check_td_alloc(${TARGET_NAME} ${ARGN})
  oda_init_rpath()
  if(STATIC_OPENSSL)
    add_definitions(-DSTATIC_OPENSSL)
  endif(STATIC_OPENSSL)
  if(ODA_SHARED)
    add_definitions(-D_TOOLKIT_IN_DLL_)
  endif(ODA_SHARED)
  if (CMAKE_WINRT)
    oda_add_executable(${TARGTE_NAME} WIN8RT ${${TARGET_NAME}_SRCS})
  else()
    oda_add_executable(${TARGET_NAME} ${${TARGET_NAME}_SRCS})
  endif()
  oda_link_libraries (${TARGET_NAME} ${ARGN})
  if(MSVC OR BORLAND OR WINDOWS_GCC)
    set_target_properties( ${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
  else(MSVC OR BORLAND OR WINDOWS_GCC)
    if(ODA_RELEASE)
      add_custom_command (TARGET ${TARGET_NAME} POST_BUILD COMMAND cp ${TARGET_NAME} ${ODA_BIN_DIR} 2>/dev/null || true)
      install(TARGETS ${TARGET_NAME}  RUNTIME DESTINATION ${ODA_BIN_DIR} OPTIONAL)
    else(ODA_RELEASE)
      set_target_properties( ${TARGET_NAME} PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${ODA_BIN_DIR})
    endif(ODA_RELEASE)
  endif(MSVC OR BORLAND OR WINDOWS_GCC)
  if(MSVC)
    set(CMAKE_MANIFEST ${ODA_EXE_MANIFEST})
  endif(MSVC)
  if(IOS)
    set_property(TARGET ${TARGET_NAME} APPEND_STRING PROPERTY COMPILE_FLAGS "${ODA_EMBED_BITCODE_MARKER_FLAG}")
  endif(IOS)
  oda_set_no_precompiled_header_for_file("${TKERNELBASE_ROOT}/Extensions/alloc/OdAllocOp.cpp")
ENDMACRO(oda_executable)

MACRO(oda_add_systemservices TARGET_NAME)
  #Remove ExSystemServices.cpp from TD_EXLIB and add it to every sample that link TD_EXLIB
  foreach (dep ${ARGN})
    if (${dep} STREQUAL ${TD_EXLIB})
      #message(STATUS "Add ${EXSYSTEMSERVICES_FILE} to ${TARGET_NAME}")
      oda_sources (${TARGET_NAME} "${EXSYSTEMSERVICES_FILE}")
      break()
    endif ()
  endforeach()
ENDMACRO(oda_add_systemservices)

MACRO(oda_add_definitions TARGET_NAME)
  foreach(file ${${TARGET_NAME}_SRCS})
    oda_get_last_ext(FILE_EXT ${file})
    if (${FILE_EXT} STREQUAL ".c" OR
      ${FILE_EXT} STREQUAL ".cpp" OR
      ${FILE_EXT} STREQUAL ".cxx")
      SET_SOURCE_FILES_PROPERTIES (${file} PROPERTIES
                                  COMPILE_FLAGS ${ARGN} )
    endif(${FILE_EXT} STREQUAL ".c" OR
      ${FILE_EXT} STREQUAL ".cpp" OR
      ${FILE_EXT} STREQUAL ".cxx")
 endforeach(file)
ENDMACRO(oda_add_definitions)

MACRO(oda_set_no_precompiled_header_for_file pchSourceFile)
if(MSVC)
   set_source_files_properties(${pchSourceFile} PROPERTIES COMPILE_FLAGS " /Y- ")
endif(MSVC)
ENDMACRO(oda_set_no_precompiled_header_for_file odaTargetName pchHeaderFile)

# Check TD_Alloc is linked first before other libraries (that links TD_ALLOC)
MACRO(oda_check_td_alloc TARGET_NAME)
  #set (TD_ALLOC_FOUND 0)
  set(${TARGET_NAME}_CACHE ${ARGN} CACHE STRING "Link libraries")
  foreach (dep ${ARGN})
    if ("${dep}" STREQUAL "${TD_ALLOC_LIB}")
      #message("Info: OdAllocOp.cpp will be added to ${TARGET_NAME}")
      #set (TD_ALLOC_FOUND 1)
      oda_sources (${TARGET_NAME} "${TKERNELBASE_ROOT}/Extensions/alloc/OdAllocOp.cpp")
    endif ("${dep}" STREQUAL "${TD_ALLOC_LIB}")
  endforeach()

  #if (NOT ${TD_ALLOC_FOUND})
    #message("!!!WARNING: OdAllocOp.cpp will not be added to ${TARGET_NAME}!!!")
  #endif (NOT ${TD_ALLOC_FOUND})
ENDMACRO(oda_check_td_alloc)

# Add dependency (check the target exists before adding the dependency)
MACRO(oda_add_dependencies TARGET_NAME)
  foreach (dep ${ARGN})
    if(TARGET ${dep})
      add_dependencies(${TARGET_NAME} ${dep})
    endif()
  endforeach()
ENDMACRO(oda_add_dependencies)

if(ODA_SHARED AND (MSVC80 OR MSVC90 OR MSVC10 OR MSVC11 OR MSVC12) AND NOT WINRT AND NOT WIN64 AND NOT WINCE)
add_definitions(-DODA_LICENSING_ENABLED)
endif()
#add_definitions(-DODA_LICENSING_DEBUG)

MACRO(ODA_SET_PRECOMPILED_HEADER odaTargetName pchHeaderFile pchSourceFile)
if(MSVC)
  set_target_properties(${odaTargetName} PROPERTIES COMPILE_FLAGS "/Yu${pchHeaderFile}")
  set_source_files_properties(${pchSourceFile} PROPERTIES COMPILE_FLAGS "/Yc${pchHeaderFile}")
endif(MSVC)
ENDMACRO(ODA_SET_PRECOMPILED_HEADER odaTargetName pchHeaderFile pchSourceFile)

MACRO(ODA_SET_PRECOMPILED_HEADER_FOR_FILE pchSourceFile pchHeaderFile)
if(MSVC)
  set_source_files_properties(${pchSourceFile} PROPERTIES COMPILE_FLAGS " /Yc\"${pchHeaderFile}\" /Fp\"\$\(IntDir\)/${pchHeaderFile}.pch\" ")
endif(MSVC)
ENDMACRO(ODA_SET_PRECOMPILED_HEADER_FOR_FILE odaTargetName pchHeaderFile pchSourceFile)

MACRO(ODA_BLOCK_PRECOMPILED_HEADER_FOR_FILE)
if(MSVC)
  foreach(srcFile ${ARGV})
    set_source_files_properties(${srcFile} PROPERTIES COMPILE_FLAGS " /Y- ")
  endforeach()
endif(MSVC)
ENDMACRO(ODA_BLOCK_PRECOMPILED_HEADER_FOR_FILE sourceFile)

MACRO (clear_dir FILTER)
file(GLOB FILES_LIST ${FILTER})
FOREACH( _FILE ${FILES_LIST} )
  file(REMOVE ${_FILE})
ENDFOREACH()
ENDMACRO()

if(TB_BUILD)
 add_definitions(-DTB_ENABLED)
endif(TB_BUILD)

# The macro define C macros for build Spatial related binaries
MACRO (oda_spatial_definitions)
  if(MSVC)
    add_definitions(-DSPA_NO_AUTO_LINK)
    if(${CMAKE_BUILD_TYPE} STREQUAL "Debug")
      add_definitions(-DSPA_DEBUG)
    endif()
  endif(MSVC)
ENDMACRO()

function(oda_get_last_ext _ext_out _path_in)
  string(REGEX MATCH "\\.[^.]*$" _ext_out_loc ${_path_in})
  set(${_ext_out} ${_ext_out_loc} PARENT_SCOPE)
endfunction(oda_get_last_ext _ext_out _path_in)

function(ODA_SAFE_COPY SOURCE DEST)
  if(NOT PACKAGE_MODE)
    FILE(COPY ${SOURCE} DESTINATION ${DEST})
  endif(NOT PACKAGE_MODE)
endfunction(ODA_SAFE_COPY)

# The macro makes a relative to the current binary (i.e project) path
# Useful to be used in post build events for projects distributed to customers (Windows projects, for example)
MACRO (to_relative_path _path_out_var _path_in_var)
  file(RELATIVE_PATH ${_path_out_var} ${CMAKE_CURRENT_BINARY_DIR} ${_path_in_var})
  file(TO_NATIVE_PATH ${${_path_out_var}} ${_path_out_var})
ENDMACRO (to_relative_path _path_out_var _path_in_var)

MACRO (oda_qt_deploy TARGET_NAME)
if(EXISTS $ENV{QTDIR})
  if(NOT ODA_QT_DEPLOY_OPTIONS)
    set(ODA_QT_DEPLOY_OPTIONS --no-translations --no-system-d3d-compiler)
  endif(NOT ODA_QT_DEPLOY_OPTIONS)
  if(MSVC AND ${CMAKE_BUILD_TYPE} STREQUAL "Release")
    to_relative_path(DST_REL_PATH ${ODA_BIN_DIR})
    add_custom_command (TARGET ${TARGET_NAME} POST_BUILD 
      COMMAND set PATH=%PATH%\;$(QTDIR)\\bin
      COMMAND "$(QTDIR)\\bin\\windeployqt" ${ODA_QT_DEPLOY_OPTIONS} ${DST_REL_PATH}\\$<TARGET_FILE_NAME:${TARGET_NAME}>  
      COMMENT "Updating QT runtimes")
    foreach(DEP ${ARGN})
      if(TARGET ${DEP})
        add_custom_command (TARGET ${TARGET_NAME} POST_BUILD 
          COMMAND set PATH=%PATH%\;$(QTDIR)\\bin
          COMMAND "$(QTDIR)\\bin\\windeployqt" ${ODA_QT_DEPLOY_OPTIONS} ${DST_REL_PATH}\\$<TARGET_FILE_NAME:${DEP}> 
          COMMENT "Updating QT runtimes for ${DEP}")
      endif(TARGET ${DEP})
    endforeach(DEP ${ARGN})
  endif(MSVC AND ${CMAKE_BUILD_TYPE} STREQUAL "Release")
  set(ODA_QT_DEPLOY_OPTIONS FALSE)
endif(EXISTS $ENV{QTDIR})  
ENDMACRO (oda_qt_deploy TARGET_NAME)

# The macro generate .cpp file with copyright.
MACRO (ODA_GENERATE_CPP_COPYRIGHT_HEADER file_path)
  file(WRITE  ${file_path} "//\n// This file was automatically generated by cmake for test purposes.\n//\n")
  file(APPEND ${file_path} "// DO NOT EDIT MANUALLY\n//\n")
  file(APPEND ${file_path} "/////////////////////////////////////////////////////////////////////////////// \n")
  file(APPEND ${file_path} "// Copyright ${ODA_COPYRIGHT} (the \"Alliance\"). \n")
  file(APPEND ${file_path} "// All rights reserved. \n")
  file(APPEND ${file_path} "// \n")
  file(APPEND ${file_path} "// This software and its documentation and related materials are owned by \n")
  file(APPEND ${file_path} "// the Alliance. The software may only be incorporated into application \n")
  file(APPEND ${file_path} "// programs owned by members of the Alliance, subject to a signed \n")
  file(APPEND ${file_path} "// Membership Agreement and Supplemental Software License Agreement with the\n")
  file(APPEND ${file_path} "// Alliance. The structure and organization of this software are the valuable  \n")
  file(APPEND ${file_path} "// trade secrets of the Alliance and its suppliers. The software is also \n")
  file(APPEND ${file_path} "// protected by copyright law and international treaty provisions. Application\n")
  file(APPEND ${file_path} "// programs incorporating this software must include the following statement\n")
  file(APPEND ${file_path} "// with their copyright notices:\n")
  file(APPEND ${file_path} "//   \n")
  file(APPEND ${file_path} "//   This application incorporates Open Design Alliance software pursuant to a license \n")
  file(APPEND ${file_path} "//   agreement with Open Design Alliance.\n")
  file(APPEND ${file_path} "//   Open Design Alliance Copyright (C) 2002-2020 by Open Design Alliance. \n")
  file(APPEND ${file_path} "//   All rights reserved.\n")
  file(APPEND ${file_path} "//\n")
  file(APPEND ${file_path} "// By use of this software, its documentation or related materials, you\n")
  file(APPEND ${file_path} "// acknowledge and accept the above terms.\n")
  file(APPEND ${file_path} "///////////////////////////////////////////////////////////////////////////////\n\n")
ENDMACRO()

# This little macro lets you set any XCode specific property
macro (set_xcode_property TARGET XCODE_PROPERTY XCODE_VALUE)
  set_property (TARGET ${TARGET} PROPERTY XCODE_ATTRIBUTE_${XCODE_PROPERTY} ${XCODE_VALUE})
endmacro (set_xcode_property)


# This macro lets you find executable programs on the host system
macro (find_host_package)
  set (CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
  set (CMAKE_FIND_ROOT_PATH_MODE_LIBRARY NEVER)
  set (CMAKE_FIND_ROOT_PATH_MODE_INCLUDE NEVER)
  set (IOS FALSE)

  find_package(${ARGN})

  set (IOS TRUE)
  set (CMAKE_FIND_ROOT_PATH_MODE_PROGRAM ONLY)
  set (CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
  set (CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
endmacro (find_host_package)

macro (oda_qt_use_modules TARGET_NAME QT_VER)
  unset(QTLIBS)
  foreach(QTLIB ${ARGN})
  list(APPEND QTLIBS "${QT_VER}::${QTLIB}")
  endforeach(QTLIB ${ARGN})
  target_link_libraries(${TARGET_NAME} PRIVATE ${QTLIBS})
endmacro (oda_qt_use_modules TARGET_NAME QT_VER)

macro (oda_qt_add_resources RC_VAR_NAME)
  if(QT6)
    qt6_add_resources(${RC_VAR_NAME} ${ARGN})
  else(QT6)
    qt5_add_resources(${RC_VAR_NAME} ${ARGN})
  endif(QT6)
endmacro (oda_qt_add_resources RC_VAR_NAME)

macro (oda_copy_manifest TARGET_NAME)
  if(NOT PACKAGE_MODE)
    if(WIN32 OR WIN64)
      add_custom_command ( TARGET ${TARGET_NAME} POST_BUILD COMMAND copy /b /y "\"${ODA_BIN_DIR_W}\\CRT.manifest\"" "\"${ODA_BIN_DIR_W}\\${TARGET_NAME}.exe.manifest\"" )
    endif()
  endif()
endmacro (oda_copy_manifest TARGET_NAME)

macro (oda_treat_warnings_as_errors TARGET_NAME)
  if(MSVC)
    target_compile_options(${TARGET_NAME} PRIVATE /WX) #/W4
  elseif(CMAKE_CXX_COMPILER_ID MATCHES "Clang")
    target_compile_options(${TARGET_NAME} PRIVATE -Werror -Wno-bitwise-op-parentheses -Wno-logical-op-parentheses) #/Wall
  elseif(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
    target_compile_options(${TARGET_NAME} PRIVATE -Werror) #/Wall
  else()
    target_compile_options(${TARGET_NAME} PRIVATE -Werror) #/Wall
  endif()
endmacro (oda_treat_warnings_as_errors TARGET_NAME)

macro (oda_msvc_disable_warnings TARGET_NAME)
  get_target_property(_target_IMP ${TARGET_NAME} IMPORTED)
	if(MSVC AND NOT _target_IMP)
    target_compile_options(${TARGET_NAME} PRIVATE ${ARGN})
	endif()
endmacro (oda_msvc_disable_warnings TARGET_NAME)

macro (oda_clang_disable_warnings TARGET_NAME)
  if(APPLE OR ANDROID OR LINUX_CLANG OR OHOS)
    target_compile_options(${TARGET_NAME} PRIVATE ${ARGN})
  endif(APPLE OR ANDROID OR LINUX_CLANG OR OHOS)
endmacro (oda_clang_disable_warnings TARGET_NAME)

macro (oda_gcc_disable_c_warnings TARGET_NAME)
  if(LINUX_X86 OR LINUX_X64 OR LINUX_ARM64)
    target_compile_options(${TARGET_NAME} PRIVATE
      $<$<COMPILE_LANGUAGE:C>:${ARGN}>
    )
  endif()
endmacro (oda_gcc_disable_c_warnings TARGET_NAME)

macro (oda_gcc_disable_cpp_warnings TARGET_NAME)
  if(LINUX_X86 OR LINUX_X64 OR LINUX_ARM64)
    target_compile_options(${TARGET_NAME} PRIVATE
      $<$<COMPILE_LANGUAGE:CXX>:${ARGN}>
    )
  endif()
endmacro (oda_gcc_disable_cpp_warnings TARGET_NAME)


macro (oda_source_file_disable_warnings TARGET_NAME)
  get_target_property(_target_IMP ${TARGET_NAME} IMPORTED)
	if(MSVC AND NOT _target_IMP)
		set_source_files_properties(${TARGET_NAME} PROPERTIES COMPILE_FLAGS ${ARGN})
	endif()
endmacro (oda_source_file_disable_warnings TARGET_NAME)

macro (oda_file_copy_2bin INPUT_FILE)
  file(COPY ${INPUT_FILE} DESTINATION ${ODA_REAL_BIN_DIR})
endmacro (oda_file_copy_2bin INPUT_FILE)


 
macro (oda_post_build_copy_2bin TARGET_NAME INPUT_FOLDER INPUT_FILE)
  add_custom_command( TARGET ${TARGET_NAME} POST_BUILD COMMAND ${CMAKE_COMMAND} -E copy "${INPUT_FOLDER}/${INPUT_FILE}" "${ODA_REAL_BIN_DIR}/${INPUT_FILE}" COMMENT "Copying ${INPUT_FOLDER}/${INPUT_FILE} to binary folder")
endmacro (oda_post_build_copy_2bin TARGET_NAME INPUT_FILE DST_FILE)


 
macro (oda_setnew_bindir NEW_BIN_DIR)
  set(ODA_BACKUP_BIN_DIR_TEMPORARY_VAR "${ODA_BIN_DIR}")
  if (XCODE_SINGLE_CONFIGURATION)
    set(ODA_BIN_DIR "${ODA_BACKUP_BIN_DIR_TEMPORARY_VAR}/${CMAKE_BUILD_TYPE}/${NEW_BIN_DIR}")
  else ()
    set(ODA_BIN_DIR "${ODA_BACKUP_BIN_DIR_TEMPORARY_VAR}/${NEW_BIN_DIR}")
  endif()
endmacro(oda_setnew_bindir NEW_BIN_DIR)

macro (oda_restore_bindir)
  set(ODA_BIN_DIR "${ODA_BACKUP_BIN_DIR_TEMPORARY_VAR}")
endmacro(oda_restore_bindir)

# function for generating source data for XCframework of a library

function(oda_prepare_xcframework_source XCFRAMEWORK LIB HEADER_LIST)
  message(STATUS "Prepare library ${LIB} for XCframework package")
  if (IS_ABSOLUTE ${XCFRAMEWORK_DIR_SOURCE})
    set (ODA_XCFRAMEWORK_DIR ${XCFRAMEWORK_DIR_SOURCE}/)
  else (IS_ABSOLUTE ${XCFRAMEWORK_DIR_SOURCE})
    set (ODA_XCFRAMEWORK_DIR ${PROJECT_SOURCE_DIR}/${XCFRAMEWORK_DIR_SOURCE}/)
  endif (IS_ABSOLUTE ${XCFRAMEWORK_DIR_SOURCE})  
  add_custom_command(TARGET ${LIB} POST_BUILD 
    COMMAND "${CMAKE_COMMAND}" -E copy 
      "$<TARGET_FILE:${LIB}>"
      "${ODA_XCFRAMEWORK_DIR}/${LIB}/${ODA_PROJECT}/$<TARGET_FILE_NAME:${LIB}>" 
    COMMENT "Copying to ${LIB} to ${ODA_XCFRAMEWORK_DIR}")
    add_custom_command(TARGET ${LIB} POST_BUILD COMMAND mkdir -p ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers)
    list(LENGTH HEADER_LIST HEADER_LIST_LENGTH)
    if (${HEADER_LIST_LENGTH} EQUAL 0)
      message(WARNING "Header list for library ${LIB} is empty. Really, this library has no headers?")
    endif(${HEADER_LIST_LENGTH} EQUAL 0)  
    foreach(DIR ${HEADER_LIST})
    add_custom_command(TARGET ${LIB} POST_BUILD COMMAND cp -r ${DIR} ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers)
  endforeach(DIR ${HEADER_LIST})
endfunction(oda_prepare_xcframework_source)

# function for generating source data for XCframework of a library
# (optimized version: removed first unused parameter of the above function
# the above function remained for backward compatibility)

if(NOT DEFINED XCFRAMEWORK_COPY_HEADERS_CMAKE)
  set(XCFRAMEWORK_COPY_HEADERS_CMAKE:BOOL=FALSE)
endif(NOT DEFINED XCFRAMEWORK_COPY_HEADERS_CMAKE)  

function(oda_prepare_xcframework_source_optimized LIB HEADER_LIST HEADER_EXCLUDE_LIST)
  message(STATUS "Prepare library ${LIB} for XCframework package")
  if (IS_ABSOLUTE ${XCFRAMEWORK_DIR_SOURCE})
    set (ODA_XCFRAMEWORK_DIR ${XCFRAMEWORK_DIR_SOURCE}/)
  else (IS_ABSOLUTE ${XCFRAMEWORK_DIR_SOURCE})
    set (ODA_XCFRAMEWORK_DIR ${PROJECT_SOURCE_DIR}/${XCFRAMEWORK_DIR_SOURCE}/)
  endif (IS_ABSOLUTE ${XCFRAMEWORK_DIR_SOURCE})  
  add_custom_command(TARGET ${LIB} POST_BUILD 
    COMMAND "${CMAKE_COMMAND}" -E copy 
      "$<TARGET_FILE:${LIB}>"
      "${ODA_XCFRAMEWORK_DIR}/${LIB}/${ODA_PROJECT}/$<TARGET_FILE_NAME:${LIB}>" 
    COMMENT "Copying to ${LIB} to ${ODA_XCFRAMEWORK_DIR}")

  if(XCFRAMEWORK_COPY_HEADERS_CMAKE)
    file(MAKE_DIRECTORY ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers)
  else(XCFRAMEWORK_COPY_HEADERS_CMAKE)  
    add_custom_command(TARGET ${LIB} POST_BUILD COMMAND mkdir -p ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers)
  endif(XCFRAMEWORK_COPY_HEADERS_CMAKE)

  list(LENGTH HEADER_LIST HEADER_LIST_LENGTH)
  if (${HEADER_LIST_LENGTH} EQUAL 0)
    message(WARNING "Header list for library ${LIB} is empty. Really, this library has no headers?")
  endif(${HEADER_LIST_LENGTH} EQUAL 0)  
  foreach(DIR ${HEADER_LIST})
    if(XCFRAMEWORK_COPY_HEADERS_CMAKE)
      file(GLOB HEADERS_TO_COPY ${DIR})
      file(COPY ${HEADERS_TO_COPY} DESTINATION ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers)
    else(XCFRAMEWORK_COPY_HEADERS_CMAKE)  
      add_custom_command(TARGET ${LIB} POST_BUILD COMMAND cp -r ${DIR} ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers)
    endif(XCFRAMEWORK_COPY_HEADERS_CMAKE)
  endforeach(DIR ${HEADER_LIST})

  # exclude headers, i.e. remove from source directory for the XC frameworks
  if(HEADER_EXCLUDE_LIST)
    list(LENGTH HEADER_EXCLUDE_LIST HEADER_LIST_LENGTH)
    if (NOT ${HEADER_LIST_LENGTH} EQUAL 0)
      foreach(DIR ${HEADER_EXCLUDE_LIST})
        if(XCFRAMEWORK_COPY_HEADERS_CMAKE)
          message(WARNING ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})
          if(IS_DIRECTORY ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})
            file(REMOVE_RECURSIVE ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})
          else(IS_DIRECTORY ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})
            file(REMOVE ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})
          endif(IS_DIRECTORY ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})  
        else(XCFRAMEWORK_COPY_HEADERS_CMAKE)  
          add_custom_command(TARGET ${LIB} POST_BUILD COMMAND rm -rf ${ODA_XCFRAMEWORK_DIR}/${LIB}/Headers/${DIR})
        endif(XCFRAMEWORK_COPY_HEADERS_CMAKE)
      endforeach(DIR ${HEADER_EXCLUDE_LIST})
    endif(${HEADER_LIST_LENGTH} NOT EQUAL 0)
  endif(HEADER_EXCLUDE_LIST)

endfunction(oda_prepare_xcframework_source_optimized)


# macro for generating source data for XCframework of a library
# macro is the wrapper of the function (see above) which allows one-line invocation within named arguments
# (for parsing named arguments see https://cmake.org/cmake/help/latest/command/cmake_parse_arguments.html)

# sample invocation:
#
# oda_prepare_xcframework_source_macro(
# 	LIB
# 		${TD_ALLOC_LIB}
# 	HEADERS
# 		${TKERNELBASE_ROOT}/Include/OdAlloc.h
# 		${TKERNELBASE_ROOT}/Include/OdAllocExport.h
#   [HEADERS_EXLUDE]
#     # needed to eliminate duplicate header pathnames in different (two or more XCframeworks)
#     <headers to exclude from source directory for this XCframework> # !!! pathname RELATIVE to HEADERS
#     e.g:
#      OdAllocExport.h
# )
#

include(CMakeParseArguments)

macro(oda_prepare_xcframework_source_macro)
  
  set( _OPTIONS_ARGS )
  set( _ONE_VALUE_ARGS XCFRAMEWORK LIB )
  set( _MULTI_VALUE_ARGS HEADERS HEADERS_EXCLUDE)

   # parse parameters
  cmake_parse_arguments( oda_prepare_xcframework_source_macro "${_OPTIONS_ARGS}" "${_ONE_VALUE_ARGS}" "${_MULTI_VALUE_ARGS}" ${ARGN} )

  #check XCFRAMEWORKS
  if(oda_prepare_xcframework_source_macro_XCFRAMEWORK)
  
    # check LIB
    if(oda_prepare_xcframework_source_macro_LIB)
      message(STATUS ${oda_prepare_xcframework_source_macro_LIB})
    else(oda_prepare_xcframework_source_macro_LIB)
      message(FATAL_ERROR "Argument LIB not defined")  
    endif(oda_prepare_xcframework_source_macro_LIB)

    # check HEADERS
    if(oda_prepare_xcframework_source_macro_HEADERS)
      message(STATUS "${oda_prepare_xcframework_source_macro_HEADERS}")
    else(oda_prepare_xcframework_source_macro_HEADERS)
      message(WARNING "Argument HEADERS for library ${oda_prepare_xcframework_source_macro_LIB} is not defined or is empty")  
    endif(oda_prepare_xcframework_source_macro_HEADERS)

    # invoke function
    oda_prepare_xcframework_source_optimized("${oda_prepare_xcframework_source_macro_LIB}" "${oda_prepare_xcframework_source_macro_HEADERS}" "${oda_prepare_xcframework_source_macro_HEADERS_EXCLUDE}")

  endif(oda_prepare_xcframework_source_macro_XCFRAMEWORK)

endmacro(oda_prepare_xcframework_source_macro)

MACRO(oda_set_macos_bundle_properties TARGET_NAME ICON_FILE_NAME ICON_FILE_PATH)
  set(MACOSX_BUNDLE_ICON_FILE "${ICON_FILE_NAME}")
  set(MACOSX_BUNDLE_RESOURCES "${ODA_REAL_BIN_DIR}/${TARGET_NAME}.app/Contents/Resources")  
  set(MACOSX_BUNDLE_ICON "${ICON_FILE_PATH}/${MACOSX_BUNDLE_ICON_FILE}.icns")
  execute_process(COMMAND ${CMAKE_COMMAND} -E make_directory ${MACOSX_BUNDLE_RESOURCES})
  execute_process(COMMAND ${CMAKE_COMMAND} -E copy_if_different ${MACOSX_BUNDLE_ICON} ${MACOSX_BUNDLE_RESOURCES})

  set_target_properties(${TARGET_NAME} PROPERTIES
     MACOSX_BUNDLE 1
     MACOSX_BUNDLE_GUI_IDENTIFIER "${TARGET_NAME}"
     MACOSX_BUNDLE_LONG_VERSION_STRING "${TARGET_NAME} Version ${ODA_PROD_VER}"
     MACOSX_BUNDLE_BUNDLE_NAME "${TARGET_NAME}"
     MACOSX_BUNDLE_SHORT_VERSION_STRING "${ODA_PROD_VER}"
     MACOSX_BUNDLE_BUNDLE_VERSION "${ODA_PROD_VER}"
     MACOSX_BUNDLE_COPYRIGHT "${ODA_COPYRIGHT}"
     MACOSX_BUNDLE_INFO_STRING "${TARGET_NAME} ${ODA_PROD_VER}, Copyright ${ODA_COPYRIGHT}"
   )
ENDMACRO(oda_set_macos_bundle_properties)

MACRO(oda_add_macos_bundle_plugins TARGET_NAME)
   set(MACOSX_BUNDLE_PLUGINS "${ODA_REAL_BIN_DIR}/${TARGET_NAME}.app/Contents/MacOS/Plugins")
   execute_process(COMMAND ${CMAKE_COMMAND} -E make_directory ${MACOSX_BUNDLE_PLUGINS})
ENDMACRO(oda_add_macos_bundle_plugins)

MACRO(oda_set_cxx_standard TARGET_NAME cpp_standard)
    set_target_properties(${TARGET_NAME} PROPERTIES
        CXX_STANDARD ${cpp_standard}
        CXX_STANDARD_REQUIRED ON
        CXX_EXTENSIONS OFF
    )
ENDMACRO(oda_set_cxx_standard)

MACRO(copy_android_libshared JNI_LIB)
if ("${ANDROID_ABI}" STREQUAL "arm64-v8a")
  set(ANDROID_SYSROOT_ARCH "aarch64-linux-android")
elseif("${ANDROID_ABI}" STREQUAL "armeabi-v7a") 
  set(ANDROID_SYSROOT_ARCH "arm-linux-androideabi")
elseif("${ANDROID_ABI}" STREQUAL "x86_64") 
  set(ANDROID_SYSROOT_ARCH "x86_64-linux-android")
elseif("${ANDROID_ABI}" STREQUAL "x86") 
  set(ANDROID_SYSROOT_ARCH "i686-linux-android")
else() 
  message(FATAL_ERROR "Unsupported ANDROID_ABI: ${ANDROID_ABI}")
endif()

if(ODA_SHARED)
add_custom_command(
  TARGET ${JNI_LIB}
  POST_BUILD
  COMMAND ${CMAKE_COMMAND} -E copy
    "${ANDROID_NDK}/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/${ANDROID_SYSROOT_ARCH}/libc++_shared.so"
    "${ODA_BIN_DIR}/libc++_shared.so"
)
endif()
ENDMACRO(copy_android_libshared)
